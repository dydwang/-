import  util  from '../util.js'

let user = {}
let src = 'http://192.168.1.3:3000/users/' //当前接口文件夹
user.addCourse = function (data, callback) {
  util(data, src+'addCourse', callback)
}
user.getCourse = function (data, callback) {
  util(data, src+'getCourse', callback)
}
user.delCourse = function (data, callback) {
  util(data, src+'delCourse', callback)
}
user.addUser = function (data, callback) {
  util(data, src+'addUser', callback)
}
user.getUser = function (data, callback) {
  util(data, src+'getUser', callback)
}

user.addBlog = function (data, callback) {
  util(data, src+'addBlog', callback)
}

user.getBlog = function (data, callback) {
  util(data, src+'getBlog', callback)
}

user.delBlog = function (data, callback) {
  util(data, src+'delBlog', callback)
}
user.addComment = function (data, callback) {
  util(data, src+'addComment', callback)
}
user.getComment = function (data, callback) {
  util(data, src+'getComment', callback)
}


export default user