// pages/index/info/info.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    options:{},
    text:'',
    comment:[]
  },
  bindChangeName(e){
    this.setData({
      text:e.detail.value
    })
  },
  getTime(time){
    let that={};
    let type='Y-M-D h:m:s';
    that.date=new Date(parseInt(time));
    that.Y=that.date.getFullYear();
    that.M=that.date.getMonth()+1;
    that.D=that.date.getDate();
    that.h=that.date.getHours();
    that.m=that.date.getMinutes();
    that.s=that.date.getSeconds();
    that.w=that.date.getDay();
    that.timeType={
      'Y': that.Y,
      'M': that.M,
      'D': that.D,
      'h': that.h,
      'm': that.m,
      's': that.s,
      'w': that.w,
    }
    const array=type.split('');
    let times='';
    array.forEach((val,index,arr)=>{
      times+=that.timeType[val]===undefined?val:that.timeType[val]
    })
    return times;
  },
  primary(){
    if(this.data.text&&getApp().globalData.userInfo){

      let cnt={
          text:this.data.text,
          blogId:this.data.options.ids
      }
      cnt.nickName=getApp().globalData.userInfo.nickName
      cnt.ids=Date.now()
      cnt.userImg=getApp().globalData.userInfo.avatarUrl
      getApp().globalData.$api.addComment(cnt,res=>{
        if(res){

          this.setData({
            comment:this.data.comment.splice(0,0,cnt)
          })
          wx.showToast({
            title: '发表成功',
            icon: 'success',
            duration: 1000
          })
        }
      })
    }else{
      wx.showToast({
        title: '请输入完整或先登陆',
        icon: 'none',
        duration: 1000
      })
    }
  },
  getComment(){
    let cnt={
      blogId:this.data.options.ids
    }
    getApp().globalData.$api.getComment(cnt,res=>{
      if(res){
        console.log(res)
        res.forEach(val=>{
          val.times=this.getTime(val.ids)
        })
        this.setData({
          comment:res
        })
      }
    })
  },
  getTime(time){
    let that={};
    let type='Y-M-D h:m:s';
    that.date=new Date(parseInt(time));
    that.Y=that.date.getFullYear();
    that.M=that.date.getMonth()+1;
    that.D=that.date.getDate();
    that.h=that.date.getHours();
    that.m=that.date.getMinutes();
    that.s=that.date.getSeconds();
    that.w=that.date.getDay();
    that.timeType={
      'Y': that.Y,
      'M': that.M,
      'D': that.D,
      'h': that.h,
      'm': that.m,
      's': that.s,
      'w': that.w,
    }
    const array=type.split('');
    let times='';
    array.forEach((val,index,arr)=>{
      times+=that.timeType[val]===undefined?val:that.timeType[val]
    })
    return times;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    options.times=this.getTime(options.ids)
    console.log(options)
    this.setData({
      options:options
    })
    this.getComment()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getComment()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})