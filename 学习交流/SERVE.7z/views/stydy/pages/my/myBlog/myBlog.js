// pages/my/myBlog/myBlog.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tableData:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  myBlog(){
    let cnt={
      nickName:getApp().globalData.userInfo.nickName,
    }
    getApp().globalData.$api.getBlog(cnt,res=>{
      if(res) {
        res.forEach(val=>{
          val.times=this.getTime(val.ids)
        })
        this.setData({
          tableData:res
        })
      }
    })
  },
  getTime(time){
    let that={};
    let type='Y-M-D h:m:s';
    that.date=new Date(parseInt(time));
    that.Y=that.date.getFullYear();
    that.M=that.date.getMonth()+1;
    that.D=that.date.getDate();
    that.h=that.date.getHours();
    that.m=that.date.getMinutes();
    that.s=that.date.getSeconds();
    that.w=that.date.getDay();
    that.timeType={
      'Y': that.Y,
      'M': that.M,
      'D': that.D,
      'h': that.h,
      'm': that.m,
      's': that.s,
      'w': that.w,
    }
    const array=type.split('');
    let times='';
    array.forEach((val,index,arr)=>{
      times+=that.timeType[val]===undefined?val:that.timeType[val]
    })
    return times;
  },
  deleteBlog(e){
    let index=e.target.dataset.index
    let cnt={
      ids:this.data.tableData[index].ids
    }

    getApp().globalData.$api.delBlog(cnt,res=>{
      if(res){
        let tabledata=this.data.tableData
        tabledata.splice(index,1)
        this.setData({
          tableData:tabledata
        })
        wx.showToast({
          title: '删除成功',
          icon: 'none',
          duration: 500
        })
      }
    })

  },
  onLoad: function (options) {
    this.myBlog()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.myBlog()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.myBlog()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})