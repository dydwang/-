
module.exports=function getTime(data){
 let that={};
    let type='Y-M-D h:m:s';
    that.date=new Date(parseInt(time));
            that.Y=this.date.getFullYear();
            that.M=this.date.getMonth()+1;
            that.D=this.date.getDate();
            that.h=this.date.getHours();
            that.m=this.date.getMinutes();
            that.s=this.date.getSeconds();
            that.w=this.date.getDay();
            that.timeType={
                'Y': this.Y,
                'M': this.M,
                'D': this.D,
                'h': this.h,
                'm': this.m,
                's': this.s,
                'w': this.w,
            }
        const array=type.split('');
        let time='';
        array.forEach((val,index,arr)=>{
            time+=that.timeType[val]===undefined?val:that.timeType[val]
        })
        return time;
    };
