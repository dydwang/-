// pages/course/course.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:new Date(Date.now()).getUTCDay()+1,
    tableData:[]
  },
    getWeek:function(data){
      return data === 1 ? '一'
            : data === 2 ? '二'
                : data === 3 ? '三'
                    : data === 4 ? '四'
                        : data === 5 ? '五'
                            : data === 6 ? '六'
                                            : '日'
    },
  changeIndex:function(e){
    let index=e.target.dataset.index
    console.log(index)
    this.setData({
      index: index
    })
    this.getCourse()
  },
  getCourse:function(){
    let cnt= {
      nickName: getApp().globalData.userInfo.nickName,
      weeks:this.data.index
    }
          getApp().globalData.$api.getCourse(cnt,res=>{
            if(res){
              this.setData({
                tableData:res
              })
              console.log(this.data.tableData)
            }
    })
  },
  primary:function(){
    wx.navigateTo({
      url:'./addCourse/addCourse'
    })
  },
  deleteBlog(e){
    let index=e.target.dataset.index
    let cnt={
      ids:this.data.tableData[index].ids
    }

    getApp().globalData.$api.delCourse(cnt,res=>{
      if(res){
        let tabledata=this.data.tableData
        tabledata.splice(index,1)
        this.setData({
          tableData:tabledata
        })
        wx.showToast({
          title: '删除成功',
          icon: 'none',
          duration: 500
        })
      }
    })

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({ title: '课表' })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getCourse()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})