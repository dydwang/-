let linkSql =require('../linkSql')

class Lmsq{
    constructor(){

    }
    add(table,data,call){
        let sql=`INSERT INTO tbl_${table}(`
        for (let i in data){
            sql+=i+','
        }
        sql=sql.substr(0,sql.length-1)+') values( '
        for (let i in data){
            if(typeof data[i]==='string'){
                sql+=` "${data[i]}" ,`
            }else{
                sql+=` ${data[i]} ,`
            }
        }
        sql=sql.substr(0,sql.length-1)+')'
        linkSql(sql,call)
    }
    get(table,data=false,options,call){
        let sql=`select * from tbl_${table}`

        //条件查询
        if(data){
            sql+=' where '
            for (let i in data){
                if(typeof data[i]==='string'){
                    sql+=` ${i} = "${data[i]}" and`
                }else{
                    sql+=` ${i} = ${data[i]} and`
                }
            }

         //顺序
            if(options.likes)   {
                for (let i in options.likes){
                    if(typeof options.likes[i]==='string'){
                        sql+=` ${i} like "${options.likes[i]}" and`
                    }else{
                        sql+=` ${i} like ${options.likes[i]} and`
                    }
                }
                sql=sql.substr(0,sql.length-3)
            }else{
                sql=sql.substr(0,sql.length-3)
            }

         if(options.orderBy) {
             if(options.orderBy.length<2||options.orderBy[1]==='asc') {
                 sql+=` order by ${options.orderBy[0]} `
             }else{
                 sql+=` order by ${options.orderBy[0]} DESC`
             }
         }

            //模糊查询


        }
        linkSql(sql,call)
    }

    up(table,where,data=false,call){
        let sql=`UPDATE tbl_${table} set `
        for (let i in data){
            if(typeof data[i]==='string'){
                sql+=` ${i} = "${data[i]}" ,`
            }else{
                sql+=` ${i} = ${data[i]} ,`
            }
        }
        sql=sql.substr(0,sql.length-1)+ ' where '
        for (let w in where){
            if(typeof data[w]==='string'){
                sql+=` ${w} = "${data[w]}" and`
            }else{
                sql+=` ${w} = ${data[w]} and`
            }
        }
        sql=sql.substr(0,sql.length-3)
        linkSql(sql,call)
    }

    del(table,data,call){
        let sql=`delete from tbl_${table} `
        if(data){
            sql +=' where '
            for (let i in data){
                if(typeof data[i]==='string'){
                    sql+=` ${i} = "${data[i]}" and`
                }else{
                    sql+=` ${i} = ${data[i]} and`
                }
            }
            sql=sql.substr(0,sql.length-3)
            linkSql(sql,call)
        }
    }
}

module.exports= new Lmsq()