module.exports = function (table) {
    console.log(table)
}