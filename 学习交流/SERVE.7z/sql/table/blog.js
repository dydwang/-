let table=[
    ['title','varchar(100) not null'],
    ['ids','varchar(20) primary key'],
    ['mains','varchar(200) not null'],
    ['nickName','varchar(100) not null'],
    ['sorts','varchar(100) not null'],
    ['userImg','varchar(200) not null'],
]
module.exports=table
