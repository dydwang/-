let table=[
    ['input','varchar(100) not null'],
    ['ids','varchar(20) primary key'],
    ['weeks','varchar(20) not null'],
    ['timeStart','varchar(100) not null'],
    ['timeEnd','varchar(100) not null'],
    ['nickName','varchar(100) not null'],
]
module.exports=table
