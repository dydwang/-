let table=[
    ['text','varchar(100) not null'],
    ['ids','varchar(20) primary key'],
    ['blogId','varchar(200) not null'],
    ['nickName','varchar(100) not null'],
    ['userImg','varchar(200) not null'],
]
module.exports=table
