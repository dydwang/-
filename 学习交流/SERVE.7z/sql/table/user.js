let table=[
    ['names','varchar(20) not null'],
    ['nickName','varchar(20) primary key'],
    ['old','varchar(20) not null'],
    ['grade','varchar(20) not null'],
    ['stuId','varchar(20) not null'],
    ['ids','varchar(20) not null']
]
module.exports=table
