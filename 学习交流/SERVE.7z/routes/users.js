var express = require('express');
var router = express.Router();
let lmsq =require('../sql/fun/index')


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/addCourse', function(req, res, next) {
  lmsq.add('course',req.body,call=>{
    res.send(call);
  })
});

router.post('/getCourse', function(req, res, next) {
  lmsq.get('course',req.body,{orderBy:['timeStart']},call=>{
    res.send(call);
  })
});
router.post('/delCourse', function(req, res, next) {
  lmsq.del('course',req.body,call=>{
    res.send(call);
  })
});

router.post('/getUser', function(req, res, next) {
  lmsq.get('user',req.body,{},call=>{
    res.send(call);
  })
});

router.post('/addUser', function(req, res, next) {
  const nickName=req.body.nickName
  lmsq.add('user',req.body,call=>{
    if(!call){
      lmsq.up('user',{nickName:nickName},req.body,c=>{
        res.send(c)
      })
    }})
})

router.post('/addBlog', function(req, res, next) {
  lmsq.add('blog',req.body,call=>{
    res.send(call);
  })
});

router.post('/getBlog', function(req, res, next) {
  let options={}
  if(req.body.title){
    options={
      likes:{
        title:`%${req.body.title}%`
      }
    }
    delete req.body.title;
  }

  lmsq.get('blog',req.body,options,call=>{
    res.send(call);
  })
});

router.post('/delBlog', function(req, res, next) {
  lmsq.del('blog',req.body,call=>{
    res.send(call);
  })
});

router.post('/getComment', function(req, res, next) {
  lmsq.get('comment',req.body,{},call=>{
    res.send(call);
  })
});

router.post('/addComment', function(req, res, next) {
  lmsq.add('comment',req.body,call=>{
    res.send(call);
  })
});


module.exports = router;
